<div class="ispa-map">
  <div class="map-tools">
    <input  id="location-search" type="text" placeholder="Search location" class="location-search browser-default" autocomplete="none">
    <button data-tooltip="Current location" data-position="bottom" class="map-near  tooltipped material-icons click-btn">location_on</button> 
     <button data-tooltip="Current location" data-position="bottom" class="close-loc tooltipped material-icons right click-btn">close</button>    
  </div>
  <div class="selected-location" data-location="" data-location-name="">No location selected</div> 
  <div class="map-body">
    <div  id="map" class="map">
      
    </div>
  </div>
  <div class="center sel-loc">
    <button data-tooltip="Select location" data-position="bottom" class="click-btn tooltipped select-location">Select location</button>
  </div> 
</div>