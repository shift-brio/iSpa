<!-- bus-menu -->

<!-- <div data-item="chats" class="menu-item  tooltipped" data-menu="chats" data-tooltip="Notifications" data-position="top">
		<i class="material-icons menu-icon">chat</i>
		<div class="menu-notifs chat-notif"><?php echo $count_chats; ?></div>	
		<div class="menu-name">Messages</div>
	</div>	 -->
					
<!-- <div data-item="wallet" class="menu-item  tooltipped" data-menu="wallet" data-tooltip="Notifications" data-position="top">
	<i class="material-icons menu-icon">credit_card</i>	
	<div class="menu-name">Subscription</div>
</div> -->