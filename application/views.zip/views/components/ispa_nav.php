<nav class="ispa-nav">
	<button data-tooltip="Open menu" data-position="right" class="menu-btn tooltipped click-btn material-icons">menu</button>
	<input placeholder="Explore" type="text" class="ispa-explorer browser-default place_change">
	<div class="right ispa-tools">
		<div class="loader_indic">
			<div class="loader-1 center_"><span></span></div>
		</div>
		<!-- <div class="ispa-tag">iSpa</div> -->
		<button data-tooltip="Talk to us" data-position="left"  class="material-icons tooltipped click-btn ispa-help-chat">help</button>
	</div>
</nav>