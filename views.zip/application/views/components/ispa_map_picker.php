<div class="ispa-map-picker">
	<div class="ispa-row row">
		<div class="col s12 m8 l6 ispa-map-picker-body">
			<?php $this->load->view("maps"); ?>
		</div>
	</div>
</div>