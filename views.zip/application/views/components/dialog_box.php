<!-- dialog box -->
<div class="ispa-dialog">
	<div class="dialog-cont">
		<div class="dialog-body"></div>
		<div class="dialog-tools">
			<button class="click-btn dialog-tool negative">
				Cancel
			</button>
			<button class="click-btn dialog-tool positive right">
				Ok
			</button>
		</div>
	</div>
</div>