function f_com(comm,table = false){	
	$("input.mouseover").attr('value',10)		
	var user = $(".b-user")
	var head = $(".b-head")
	var comment = $(".b-com")
	var loader = $(".comm-loader")
	var content = $(".b-pcont")
	var detail = $(".p-det")
	if (comm.length != 32 && comm.length != 40 && comm.length != 37 && comm.length != 45) {
		if (comm == '') {
			comm = "";
		}
		else{
			comm = comm.value;
		}
	}
	else{
	comm =  comm;		
	}			
	if (comm == '') {
		$(".barr").fadeOut(200)
		user.html('');
		head.html('');
		comment.html('')
		content.html('')
		detail.html('');
		$('body').css('overflow-y','auto')
		//refresh_page();
	}
	else{
		if (!$(".barr").html()) {
			var x = $(".main-url").val()+"posts/view/"+comm;
			if (x != window.location.href) {
				window.location.replace(x)
			}
		}
		else
		$('body').css('overflow','hidden')
		$(".barr").fadeIn(150)
		if (table != false) {
			var table = table
		}
		else if($(".p_table"+comm).attr("table") != null){
			var table = $(".p_table"+comm).attr("table")
		}
		else{
			var table ='posts';
		}
		loader.removeClass("hidden")		
		$.ajax({
			url:$(".main-url").val()+"getPostData",
			type:"POST",
			headers:{'user':'Talk'},
			data:{comm:comm,table:table},
			success:function(data){
				loader.addClass("hidden")
				if (data.status == true) {
					user.html(data.user);
					head.html(data.head);
					comment.html(data.comment)
					content.html(data.content)
					detail.html(data.detail);										
				}
				else{
					head.html("Post could not be found")
				}
			},
			error:function(){
				loader.addClass("hidden")
				head.html("Post could not be found")
				user.html("")				
				comment.html("")
				setTimeout(function(){
					var v =""
					f_com(v)
				},2000)
			}
		})
	}
}
function c_sh(){
	$(".search_result").hide()
	$(".post_search").val('')
	$(".s_rs").html('')
}
$(document).ready(function(){
	$(".post_search").on('keyup',function(){
		$(".search_result").show()
		var key = $(this).val()
		var loader = $(".main-loader")
		if (key.length > 20) {
			$(".key").html(key.substr(0, 18)+" ...")
		}
		else{
			$(".key").html(key)
		}
		if (key.length > 2) {
			loader.show()
			$.ajax({
				url:$(".main-url").val()+"searchPost",
				type:'post',
				data:{key:key},
				success:function(data){
					if (data == false) {
						$(".s_rs").css('font-size','1.5em')
						$(".s_rs").css('color','#3CA2C0')
						$(".s_rs").html("No posts found")
					}
					else{						
						$(".s_rs").css('color','')
						$(".s_rs").css('font-size','1em')
						$(".s_rs").html(data)
					}
					$("input.mouseover").attr('value',2)
					loader.hide()
				},
				error:function(){
					$(".s_rs").css('color','#cd0000')
					$(".s_rs").css('font-size','1.5em')
					$(".s_rs").html("An error occurred")
					loader.hide()
				}
			})
		}
		else if(key.length < 1){
			c_sh()
		}
	})
})