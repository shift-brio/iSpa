function ajaxCall() {
        $.ajax({
            url: "index.php/trends", 
            success: (function (result) {
                $("#trends").html(result);
            })
        })
    };
    ajaxCall(); 
    setInterval(ajaxCall, (180* 1000)); 

function messages() {
        $.ajax({
            url: "index.php/messages/get", 
            success: (function (result) {
                $("#messages_content_wrapper").html(result);
            })
        })
    };
    messages(); 
    setInterval(messages, (10* 1000));

