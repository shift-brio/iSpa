;(function($){
  $.fn.customerPopup = function (e, intWidth, intHeight, blnResize) {
    
    // Prevent default anchor event
    e.preventDefault();
    
    // Set values for window
    intWidth = intWidth || '500';
    intHeight = intHeight || '400';
    strResize = (blnResize ? 'yes' : 'no');

    // Set title and open popup with focus on it
    var strTitle = ((typeof this.attr('title') !== 'undefined') ? this.attr('title') : 'Social Share'),
        strParam = 'width=' + intWidth + ',height=' + intHeight + ',resizable=' + strResize,            
        objWindow = window.open(this.attr('href'), strTitle, strParam).focus();
  }
  
  /* ================================================== */
  
  $(document).on('mouseover',function () {
    $('.customer.share').on("click", function(e) {
      $(this).customerPopup(e);
    });
  });
    
}(jQuery));
$(document).on('mouseover',function() {
    $('.fb-share').click(function(e) {
        e.preventDefault();
        window.open($(this).attr('href'), 'fbShareWindow', 'height=450, width=550, top=' + ($(window).height() / 2 - 275) + ', left=' + ($(window).width() / 2 - 225) + ', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
        return false;
    });
});
var timeFormat = function(seconds) {
  var m = Math.floor(seconds / 60) < 10 ? "0" + Math.floor(seconds / 60) : Math.floor(seconds / 60);
  var s = Math.floor(seconds - (m * 60)) < 10 ? "0" + Math.floor(seconds - (m * 60)) : Math.floor(seconds - (m * 60));
  return m + ":" + s;
};


function updateScroll() {
  var element = document.getElementById("msg_cont");
  element.scrollTop = element.scrollHeight;
}
$("#trends").attr('style', 'border-radius:3px;');
$(document).ready(function() {
  $(".copy_link").click(function(){
      var l = $(".p-link");
      l.select();
      document.execCommand("copy");
  })
   $(".link-share").click(function(){
        var link = $(this).attr("data-src")
        $(".p-link").val(link);
    })
  $('[data-toggle="popover"]').popover({
    html: true,
    container: 'body'
  });
});
$(document).ready(function() {
  $('[data-toggle="tooltip"]').tooltip();
  $("#trends_").attr('style', 'border-radius:3px; margin-top:20px; max-height:200px;  width:320px;overflow-y:auto;background:#fff');
});
window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));
$(document).ready(function() {
  $("#search_box_pos").on('keyup', function() {
    $("#search_box_pos").val($(this).val());
  });
});
var base_url = $(".main-url").val()
$(document).ready(function() {
  var base_url = $(".main-url").val()
  load_pop();
  //load_trend();
  $("input#search_box_pos").on('keypress', function(e) {
    if (e.which == 13) {
      send()
    }
  });
});

load_pop = function(){
    $.ajax({
        url:$(".main-url").val()+"getPopular",
        type:"POST",
        success:function(response){
            $(".pop-div").html(response.m);
        }
    })
}
load_trend = function(){
    $.ajax({
        url:$(".main-url").val()+"getTrends",
        type:"POST",
        success:function(response){
            $(".trend-div").html(response.m);
        }
    })
}
function l_y(id)
{
  var loader = $(".comm-loader")
  var c_id=id.value;
  var auth="";        
  if (!$("#r_cd"+c_id).hasClass("in")) {
      loader.removeClass('hidden');
      $.ajax({
          url: base_url+'r_com', 
          type:'POST',        
          data:{auth:auth,c_id:c_id}, 
          success: function (result) {
            loader.addClass('hidden');
            if (result.status != false) {
                $("#r_cd"+c_id).html(result.m);                  
              }
          },
          error:function(){
              loader.addClass('hidden');
          }
       })  
  }  
}

function submitReply(id)
{
  var comment_id=id.value;    
  var reply= $("#reply_textarea"+comment_id).val();
  var auth ="";
  $.ajax({
      url:base_url+'r_comm', 
      type:'POST',
      data:{auth:auth,comment_id:comment_id,reply:reply}, 
      success: function (result) {
        if (result.status) {
          $("#reply_textarea"+comment_id).val("");
          $("#r_cd"+comment_id).html(result.data);
          $("#reply_counter"+comment_id).html(result.count); 
        }else{
          alert(resizable.m);
        }
      }
   })    
}

function c_reply(id) {
  var comment_id = id.value;
  alert(comment_id);
  var auth = "";
  $.ajax({
    url: 'posts/c_c',
    type: 'POST',
    data: {
      auth: auth,
      comment_id: comment_id
    },
    success: function(result) {
      $("#reply_counter" + comment_id).html(result);
    }
  })
}
function submitComment(id) {
  var id_ = id.value;
  var identifier = $("#post_id_comment" + id_).val();
  var url = $("#url_submit_comment").val();
  var content = $("#comment_textarea" + id_).val();
  if (content != '') {
    $("#loader_image_comm").removeClass("hidden");
    $.ajax({
      url: url,
      type: 'POST',
      data: {
        comment_data: content,
        identifier: identifier
      },
      success: function(data) {
        $("#comment_textarea" + id_).val("");
        $("#loader_image_comm").addClass("hidden");
        location.reload()
      }
    });
  };
}

function follow(user) {
  var id = user.value
  $("#followed" + id).removeClass("glyphicon-plus")
  $("#followed" + id).html("<span class='glyphicon glyphicon-refresh spin'></span>")
  $.ajax({
    url: "user/a_c",
    type: "POST",
    data: {
      id: id
    },
    success: function(data) {
      if (data == 'success') {
        $("#followed" + id).html("")
        $("#followed" + id).removeClass("glyphicon-plus")
        $("#followed" + id).addClass("glyphicon-ok")
        $("#followed" + id).attr("onclick", "");
        $("#followed" + id).attr("title", "Followed")
      } else {
        alert("An error occurred")
        $("#followed" + id).html("")
        $("#followed" + id).addClass("glyphicon-plus")
      }
    },
    error: function() {
      alert("An error occurred")
      $("#followed" + id).html("")
      $("#followed" + id).addClass("glyphicon-plus")
    }
  })
}

function vp(post) {
  var v = document.getElementById("vid" + post);
  inner = $(".buffer" + post);
  main = $(".vid-progress" + post);
  var b = Math.floor((v.buffered / v.duration) * 100);
  v.addEventListener("timeupdate", function() {
    if (!isNaN(this.duration)) {
      var width = Math.floor((v.currentTime / v.duration) * 100);
      main.attr("style", "width:" + width + "%");
      var r = v.currentTime;
      var t = v.duration;
      $(".t_count" + post).html(timeFormat(r) + "/" + timeFormat(t));
    }
    var btn = $(".play-pause" + post);
    if (v.ended) {
      btn.attr("title", 'play');
      btn.addClass("glyphicon-play");
      btn.addClass("stopped");
      btn.removeClass("glyphicon-pause");
      btn.removeClass("playing");
      btn.removeClass("paused");
    };
  });
  v.addEventListener("progress", function() {
    if (!isNaN(this.duration)) {
      var range = 0;
      var bf = this.buffered;
      var time = this.currentTime;

      while (!(bf.start(range) <= time && time <= bf.end(range))) {
        range += 1;
      }
      var bs = bf.start(range) / this.duration;
      var be = bf.end(range) / this.duration;
      var b = be - bs;
      inner.attr("style", "width:" + b * 100 + "%");
    }
  });
}

function tp(id) {
  if (id.length > 30) {
    var post = id
  } else {
    var post = id.value
  }
  var btn = $(".play-pause" + post);
  vid = $('.vid' + post);
  var v = document.getElementById("vid" + post);
  var tvd = $(".tvd").val();
  var vs = document.getElementById("vid" + tvd);
  v.addEventListener('timeupdate', vp(post), true);
  if (btn.hasClass("playing") || btn.hasClass("stopped")) {
    btn.attr("title", 'play');
    btn.removeClass("glyphicon-play");
    btn.removeClass("stopped");
    btn.addClass("glyphicon-pause");
    btn.removeClass("playing");
    btn.addClass("paused");
    if (tvd != "" && tvd != post && vs != null) {
      var btn = $(".play-pause" + tvd);
      $('.vid' + tvd).get(0).pause()
      btn.addClass("playing");
      btn.removeClass("paused");
      btn.attr("title", 'play');
      btn.addClass("glyphicon-play");
      btn.removeClass("glyphicon-pause");
    };
    vid.get(0).play()
    $(".tvd").val(post)
  } else {
    btn.addClass("playing");
    btn.removeClass("paused");
    btn.attr("title", 'pause');
    btn.addClass("glyphicon-play");
    btn.removeClass("glyphicon-pause");
    vid.get(0).pause()
    vp(post)
  }
}

function menus(setting) {
  setting = setting.value
  var set = $(".setting" + setting);
  if (set.hasClass('faded')) {
    set.fadeIn("slow")
    set.removeClass('faded')
  } else {
    set.fadeOut("slow")
    set.addClass('faded')
  }
}

function t_c(vid) {
  var post = vid.value
  var vid = document.getElementById("vid" + post);
  if (vid.requestFullscreen) {
    vid.requestFullscreen();
  } else if (vid.mozRequestFullScreen) {
    vid.mozRequestFullScreen();
  } else if (vid.webkitRequestFullscreen) {
    vid.webkitRequestFullscreen();
  }
}

function tc(control) {
  var control = $(".player-controls" + control);
  control.removeClass("hidden")
  alert(control)
}

function rc(control) {
  var control = $(".player-controls" + control);
  control.addClass("hidden");
}

function m(mt) {
  var post = mt.value
  var v = document.getElementById("vid" + post);
  vid = $('.vid' + post);
  var btn = $(".mute" + post);
  if (btn.hasClass("high")) {
    btn.addClass("low")
    btn.attr("title", "unmute");
    btn.removeClass("high")
    btn.removeClass("glyphicon-volume-up")
    btn.addClass("glyphicon-volume-off")
    vid.prop('muted', true);
  } else {
    btn.removeClass("low")
    btn.addClass("high")
    btn.attr("title", "mute");
    btn.removeClass("glyphicon-volume-off")
    btn.addClass("glyphicon-volume-up")
    vid.prop('muted', false)
  }
}

$(document).on('ready', function() {
  var count = $("input.mouseover").val()
  if (count < 10) {
    $("input.mouseover").attr('value', +2 + +count)
  }
  if (count < 3) {
    //other            
    $(".progress").each(function() {
      $(this).on("click", function(e) {
        var id = $(this).attr("id");
        var w = e.offsetX / $(this).width() * 100;
        var v = document.getElementById("vid" + id);
        var duration = v.duration;
        if (w > 100)
          w = 100;
        var cur = (duration * w) / 100
        $(this).children(".progress-bar").attr("style", "width:" + w + "%;");
        $(this).children(".m_m").title = Math.round(w);
        v.currentTime = cur;
      });
    });
    $(".media-progress").each(function() {
      var id = $(this).attr("id");
      var v = document.getElementById("vid" + id);
      $(".drag").attr("style", "width:" + v.volume * 100 + "%;");
    });
    $(".player").each(function() {
      var id = $(this).attr("value");
      var v = document.getElementById("vid" + id);
      $(this).on("mouseover", function() {
        $(".t" + id).fadeIn("slow")
      })
      $(this).on("mouseleave", function() {
        var btn = $(".play-pause" + id);
        if (btn.hasClass('paused')) {
          $(".t" + id).fadeOut("slow")
        }
      })
      $(".rpt" + id).on("click", function() {
        if ($(this).attr("value") == 'off') {
          v.loop = false;
          $(this).attr("value", "on")
        } else {
          v.loop = true;
          $(this).attr("value", "off")
        }
      })
      w = $(".vid" + id).attr("volume") * 100;
      $(".drag" + id).attr("style", "width:" + w + "%;");
      v.volume = w / 100;
    });
    $(".player").each(function() {
      $(this).mousedown(function(e) {
        var id = $(this).attr("value");
        if (e.button == 2) {
          $(".sto" + id).click()
          return false;
        }
        return true;
      });
    });
    $(".video").each(function() {
      $(this).on("right-click", function() {
        //alert("right")
      })
    });
    $(".v-control").each(function() {
      $(this).on("click", function(e) {
        var id = $(this).attr("value");
        var w = e.offsetX / $(this).width() * 100;
        var v = document.getElementById("vid" + id);
        if (w > 100)
          w = 100;
        $(".drag" + id).attr("style", "width:" + w + "%;");
        v.volume = w / 100;
      });
    });
    $(".player").each(function() {
      var id = $(this).attr("value");
      $(".vid" + id).on("click", function(e) {
        //tp(id)                 
      });
    });

    //main
    var lesstext = "less";
    var moretext = "... See More";
   /* $(".main-content").each(function() {
      var div = $(this);
      var show = 300;
      var id = "span" + div.attr("id")
      html = div.html()
      var new_h = html.substr(0, show);
      var remaining = html.substr(show, html.length)
      var text = new_h + '<span id="' + id + '" class="hidden">' + remaining + '</span>&nbsp;<a style="text-decoration:none;" value="' + id + '" class="morelink">' + moretext + '</a>';
      if (html.length > show) {
        div.html(text)
      };
    })
    $(".morelink").each(function() {
      $(this).click(function() {
        var id = $(this).attr("value")
        if ($(this).hasClass("less")) {
          $(this).removeClass("less");
          $(this).html(moretext);
          $("#" + id).addClass("hidden");
        } else {
          $(this).addClass("less");
          $(this).html(lesstext);
          $("#" + id).removeClass("hidden");
        }
      })
    });*/
  };
});
$(document).ready(function() {
  $(".p_sin").each(function(){
      $(this).click(function(){
          id = $(this).attr('value');
          f_com(id,'posts')
      })
  })
  status()
});

function status() {
    var state = "";
    $.ajax({
      url: $(".m_u_r").val() + "user/this",
      type: 'POST',
      success: function() {
        $(".m_blind").hide()
        setTimeout(function() {
          status()
        }, 10000)
      },
      error: function() {
        setTimeout(function() {
          status()
        }, 10000)
        $(".m_blind").show()
      }
    });
}

function _ust() {
  var x = new(window.ActiveXObject || XMLHttpRequest)("Microsoft.XMLHTTP");
  var s;

  x.open("HEAD", "//" + window.location.hostname + "/?" /*+ Math.floor((1 +Math.random())* 0x10000)*/ , false);

  try {
    x.send()
    return x.status;
  } catch (error) {
    return x.status;
  }
}

function _cm() {
  var auth = "";
  var i = $(".m-ns").attr('value');
  if (_ust() > 0 && i == '') {
    $.ajax({
      url: $(".m_u_r").val() + 'messages/n_m',
      type: 'POST',
      data: {
        auth: auth
      },
      success: function(result) {
        if (result.status == true) {
          $(".b-cont").html(result.main);
          $("div#m_count").html(result.count);
          $("div.m_count").html(result.count);
          $(".circles_wrapper").html(result.net)
        }
      }
    })
  }
}
_cm();
setInterval(_cm, (10 * 1000));

function loadNet() {

}

function like(identifier) {
  var identifier = identifier.value;
  var auth = "";
  if (identifier != '') {
    $.ajax({
      url: base_url+'likePost',
      type: 'POST',
      data: {
        auth: auth,
        identifier: identifier
      },
      success: function(result) {
        if (result.status == 'like_exist') {
          $.ajax({
            url: $(".m_u_r").val() + 'posts/dl',
            type: 'POST',
            data: {
              auth: auth,
              identifier: identifier
            },
            success: function(result) {
              $("#likes_btn" + identifier).attr('style', 'color:#d9d9d9; ');
              $("#likes" + identifier).html(result.count);
            }
          })
        };
        if (result.status == 'liked') {
          $("#likes_btn" + identifier).attr('style', 'color:#cd0000; ');
        };
        $("#likes" + identifier).html(result.count);
      }
    })
  };
}