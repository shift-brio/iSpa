$(document).ready(function(){
	$('button[data-dismiss="post"]').click(function(){
		$('div[type="post-modal"]').hide()
	})
	$(".p-btn").click(function(){
		$(".p_err").html("")			 
		var c = $("._cl_sel").val();
		var t = $(".p_ti").val();
		var p = CKEDITOR.instances['article-ckeditor'].getData(); 
		if (c == '' || c == "--select--") {
			$("._cl_sel").addClass("err");
		}
		else{
			$("._cl_sel").removeClass("err");
			if (t.replace(/\s/g, '').length < 2) {
				$(".p_ti").addClass("emt")
			}
			else{
				$(".p_ti").removeClass("emt")
				if (p.replace(/\s/g, '').length < 1) {
					$(".p_err").html("You cannot submit a blank post")
				}
				else{
					var data = new FormData();
					$(".p_err").html("")
					if($("#media_f_i").val() != ""){
						jQuery.each(jQuery('input#media_f_i')[0].files, function(i, file) {
							data.append('file-'+i, file);
						});							
					}
					data.append('t', t);
					data.append('p', p);
					data.append('c', c);
					loader = $(".s_po")
					loader.show()
					$.ajax({
						url:$(".main-url").val()+"addPost",
						type:"post",
						data:data,
						contentType: false,       
						cache: false,             
						processData:false,
						success:function(r){
							loader.hide()
							if (r.status == false) {
								$(".p_err").html(r.m)
							}
							else{				        						        		
								$(".p_ti").val("");
								$(".p_cont").val("");
								CKEDITOR.instances['article-ckeditor'].setData()
								$(".err").removeClass("err")
								$(".emt").removeClass("emt")
								var input = $("#media_f_i");
								$("#media_f_i").replaceWith(input.val('').clone(true));
								setTimeout(function(){
									$('button[data-dismiss="post"]').click()
								},1000)
								refresh_page(15,1);
							}
						},
						error:function(){
							loader.hide()
							$(".p_err").html("An error occurred, check connection")
						}
					})
				}
			}
		}
	})		
	$("input#media_f_i").on("change",function(){
		$("input#media_f_v").val('')			
		if ($(this).val() !='') {				
			var file = this.files[0];
			var filetype = file["type"];
			var Vvids = ["video/webm","video/webm" , "video/mp4" ,"video/x-matroska","video/mpeg"];
			var vImages = ["image/gif","image/gif","image/png" ,"image/jpg","image/jpeg" , "image/svg+xml" ,"image/vnd.microsoft.icon"];
			if ($.inArray(filetype,vImages) > 0) {
				readURL(this);
				$('#on_c').show()
				$("._vid_u").html("")
			}
			else if($.inArray(filetype,Vvids) > 0){
				$("._c_fl").show()
				$("._vid_u").html("video: " + $(this).val())
				$('#on_c').hide();
				$('#on_c').attr("src","")
			}
			else{
				$("._vid_u").html(filetype)
			}
		};					
	})		
	$("._c_fl").click(function(){
		$('input[type="file"]').val("")
		$('#on_c').attr('src', '');
		$("._vid_u").html("")
		$(this).hide()
	})
	$('[data-target="#new_post"]').click(function(){
		$('.post-modal').fadeIn(150)
	})
})
function readURL(input) {		
	if (input.files && input.files[0]) {
		var reader = new FileReader();

		reader.onload = function (e) {
			$("._c_fl").show()
			$('#on_c').attr('src', e.target.result);
		}

		reader.readAsDataURL(input.files[0]);
	}
	else{
		$("._c_fl").hide()
	}
}	
/*if ($('#on_c').attr('src') == null ) {
	$('#on_c').attr('src', e.target.result);								    
}
else{
	var imager = '<img id="on_c_n" src="'+e.target.result+'" class="_m_im">';
	$("._media").append(imager)
}*/