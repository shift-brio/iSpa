$(document).ready(function () {
        $("button#btn_submit").on('click',function () {              
            var  email = $("input#login_email").val();
            var pass= $("input#login_password").val();
            if (email==''&&pass!='') 
              {                
               alert("Enter your email  address");
              };
            if (pass==''&&email!='') 
            {              
             alert("Enter your password");
            };
            if (email==''&&pass=='') {              
              alert("Enter your email  address And Password");
            };
            if (pass!='' && email!='') {              
             $(".main-loader").removeClass('hidden');    
              $.ajax({
                url:$("input#login_url").val(),
                type:'POST',
                data:{email:email,password:pass},
                success:function (data) {
                    if (data=="denied") {
                      $(".main-loader").addClass('hidden');    
                      alert("Invalid username or password");
                    };
                    if(data=="granted")
                    {
                      $(".main-loader").addClass('hidden'); 
                      location.reload();
                    }
                }
            });        
            };                         
        });
    });
function share()
 {
    var table=$(".share_column").val();
    var title=$(".share_title").val();   
    var image=$(".share_imager").attr("src");
    var content=$(".share_content").val();
    var share_url=$(".share_url").val();
    var auth="";
    if (title!='') {
        $(".main-loader").removeClass("hidden");
    $.ajax({
        url:'share/send',
        type:'POST',
        data:{table : table , title : title,image : image,content : content,auth : auth,url:share_url},
        success:function (data) {           
           if(data == ''){
            $(".main-loader").addClass("hidden");
            location.reload();
           }
           if(data !='')  
           {
            $(".main-loader").addClass("hidden");
            alert("Oops,an error occured")
            location.reload();
           }  
        }
    });
   };
 } 
 $(document).ready(function () {
        $("#login_password").on('keypress',function (e) {
            if(e.which == 13) {
                $("#btn_submit").click();                              
             }    
        });
  });