var timeFormat = function(seconds){
		var m = Math.floor(seconds/60)<10 ? "0"+Math.floor(seconds/60) : Math.floor(seconds/60);
		var s = Math.floor(seconds-(m*60))<10 ? "0"+Math.floor(seconds-(m*60)) : Math.floor(seconds-(m*60));
		return m+":"+s;
}; 
(function($, window, undefined) {
    //is onprogress supported by browser?
    var hasOnProgress = ("onprogress" in $.ajaxSettings.xhr());

    //If not supported, do nothing
    if (!hasOnProgress) {
        return;
    }
    
    //patch ajax settings to call a progress callback
    var oldXHR = $.ajaxSettings.xhr;
    $.ajaxSettings.xhr = function() {
        var xhr = oldXHR();
        if(xhr instanceof window.XMLHttpRequest) {
            xhr.addEventListener('progress', this.progress, false);
        }
        
        if(xhr.upload) {
            xhr.upload.addEventListener('progress', this.progress, false);
        }
        
        return xhr;
    };
})(jQuery, window);


(function($){

    $.fn.extend({ 

        addTemporaryClass: function(className, duration) {
            var elements = this;
            setTimeout(function() {
                elements.fadeOut("slow");
                elements.removeClass(className)
                elements.addClass('hidden');
            }, duration);

            return this.each(function() { 
                elements.removeClass('hidden')               
                $(this).addClass(className);                
            });
        }
    });

})(jQuery);
function r_c(){
    var num="";
    $.ajax({
            url:'user/r_c', 
            type:'POST',
            data:{num:num}, 
            success: function (result) { 
            $("#c_t").attr('data-content',result);          
            }
        })
    };
r_c(); 
setInterval(r_c, (3600* 1000));

$(document).ready(()=>{
    more_func();
})
more_func = function(){
    $(".more-text").each(function(){
        $(this).click(function(){               
            $(this).parent().parent().parent().removeClass("less");
            $(this).parent().parent().remove();
        })
    })
}
$(document).ready(function () {
        $(".m-searcher").click(function(){
            $(".m-search").toggle("slow")
        })
        rss();
        $("#search_box").on('keyup',function () {
            var key = $(this).val();
            if (key.length==0) {
                $("#user_result").html('');
            };
            if (key.length>=3) {
            $(".main-loader").show();
            $.ajax({
                url:$("#user_search_url").val(),
                type:'GET',
                data:'keyword='+key,
                success:function (data) {
                    $(".main-loader").hide();
                    if (data != 'error') {
                        $("#user_result").html(data);
                       $("#user_result").slideDown('fast');                   
                    }
                    else
                    {
                        alert("error")
                    }
                }
             });
            };
        });
    });
window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));

;(function($){
  $.fn.customerPopup = function (e, intWidth, intHeight, blnResize) {
    
    // Prevent default anchor event
    e.preventDefault();
    
    // Set values for window
    intWidth = intWidth || '500';
    intHeight = intHeight || '400';
    strResize = (blnResize ? 'yes' : 'no');

    // Set title and open popup with focus on it
    var strTitle = ((typeof this.attr('title') !== 'undefined') ? this.attr('title') : 'Social Share'),
        strParam = 'width=' + intWidth + ',height=' + intHeight + ',resizable=' + strResize,            
        objWindow = window.open(this.attr('href'), strTitle, strParam).focus();
  }
  
  /* ================================================== */
  
  $(document).on('mouseover',function () {
    $('.customer.share').on("click", function(e) {
      $(this).customerPopup(e);
    });
  });
    
}(jQuery));
$(document).on('mouseover',function() {
    $('.fb-share').click(function(e) {
        e.preventDefault();
        window.open($(this).attr('href'), 'fbShareWindow', 'height=450, width=550, top=' + ($(window).height() / 2 - 275) + ', left=' + ($(window).width() / 2 - 225) + ', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
        return false;
    });
});

$(document).on("mouseover",function(){
        $('[data-toggle="popover"]').popover({html: true,container: ''});        
    });
$(document).on("mouseover",function(){
    $('[data-toggle="tooltip"]').tooltip();       
});

function viewpost(id)
{
    $(".popover").hide();
    var identifier=id.value;
    var auth = "";
    $("#viewPost").modal('show');
    $.ajax({
        url:'posts/get_post', 
        type:'POST',
        data:{auth:auth,identifier:identifier}, 
        success: function (result) {          
          $("#post_view").html(result);
        }
     })  
}
$(document).ready(function () {
        $(".ic-set").click(function(){
            alert($(".c_set").html());
        })
        status()
});
function status(){
    var state="";    
    $.ajax({
        url:"user/this",
        type:'POST', 
        success:function(){
            setTimeout(function(){
                status()
            },10000)
            $(".m_blind").hide()
        },
        error:function(){
            setTimeout(function(){
                status()
            },10000)
            $(".m_blind").show()
        }             
    });    
}
function submitPost()
 {   
    $("#post_err").html('');
    var title=$("#tittle").val();
    var content=$("#post_textarea").val();
    var table=$("#sel1").val();         
    var data = new FormData();
    if (title==''||title==' ') {
        $("#post_err").html('Enter post title');
    };            
    
    if (title!=''&&title!=' ' && table!='--select--') {
    if ($("#input#post_attach").val()!='') {
    $("#mainprogress").removeClass('hidden');
    jQuery.each(jQuery('input#post_attach')[0].files, function(i, file) {
    data.append('file-'+i, file);
      });
    };
    data.append('title', title);
    data.append('content', content);
    data.append('table', table);                                                 
    $.ajax({
        url:'posts/add_post',
        type:'POST',
        data:data,
        contentType: false,       
        cache: false,             
        processData:false,
        progress: function(e) {
            if(e.lengthComputable) {
                var pct = (e.loaded / e.total) * 100 + '%';
                $("#innerprogress").attr('style','width:'+pct+';')
            }
            else {
                $("#mainprogress").addClass('hidden');
            }
        },
         success:function (data) {
            if (data.length>100) {  
            $("#post_err").html("An unknown error occurred with the uploaded file");
            $("#mainprogress").addClass('hidden');
            $("#innerprogress").attr('style','width:;')                    
            };
            if (data.length<100) {  
            $("#post_err").html(data);
            $("#mainprogress").addClass('hidden');
            $("#innerprogress").attr('style','width:;')                    
            };    
            if (data=='') {
                //ajaxRefresh();
                $("#mainprogress").addClass('hidden');
                $("#innerprogress").attr('style','width:;')
                $("#tittle").val('');
                $("#post_textarea").val('');
                $('input#post_attach').val('') 
                $("#sel1").val('--select column--');              
                //clear_file();
                refresh_page();
                $(".typer").click();
                $("#posted_div").addTemporaryClass("unhidden", 5000);
            };                 
        }               
    });                   

    };
 }
 function clear_file()
{    
    var input = $("#post_attach");
    input.replaceWith(input.val('').clone(true));
}

function load_page(){     
    $("#"+ $(".page-holder").val()).removeClass('active')    
    var pager =  $("#" + $(".page-holder").val()).attr('value');
    var page = 'country'      
    $(".main-loader").show()
    var country = $("#country_pager").val()
    if ($(".page-holder").val() != 'feed_pager') {
        $.ajax({
        url:"posts/load",
        type:"POST",
        data:{page:page,country:country,pager:pager},
        success:function(data){
            if (data == '') {
                $(".main-loader").hide()
                $("#selectCountry").modal('hide')
            }
            else{
                $(".main-loader").hide()
                $(".page-content-wrapper").html(data)
                $("input.mouseover").attr('value',1)
                $("#selectCountry").modal('hide')  
                more_func();              
            }
        },
        error:function(){
            $(".main-loader").hide()
            $("#selectCountry").modal('hide')
        }
    })
    }
    else{
        $(".main-loader").hide()        
        $("#selectCountry").modal('hide')
    }
}
/*$(document).ready(function(){
    var page = $(".page-holder").attr("id") 
    if (page != '') {
        $(".main-loader").show()
        $.ajax({
                url:"posts/up",
                type:"POST",
                data:{page:to,country:country},
                success:function(data){
                    rss();
                    if (data == '') {
                        $(".main-loader").hide()
                    }
                    else{
                        $(".tvd").val('');
                        $(".main-loader").hide()
                        $(".page-content-wrapper").html(data)
                        $("input.mouseover").attr('value',1)
                    }
                },
                error:function(){
                    $(".main-loader").hide()
                }
            })
    };
})*/
$(document).ready(function () {              
        $("#pager,#pager1,#pager2,#pager3,#pager4,#pager5,#pager6,#pager7,#pager8,#pager9,#feeds_pager").on('click',function () {
        var page = $(".page-holder").val()
        $(".active").removeClass("active")
        $("#"+page).removeClass('active')
        $(this).addClass('active')
        $(".page-holder").val($(this).attr('id'))
        var to = $(this).attr('value');
        $(".main-loader").show()
        if (to == 'feeds') {
            u = "getFeeds";
        }else{
            u = "getColFeeds";
        }
        if ($(this).attr('id') == 'viewposts_btn') {
            var country = $("#country_pager").val()
        }        
        else{
            var country = '';
            $.ajax({
                url:u,
                type:"POST",
                data:{col:to},
                complete:function(){
                    $(".main-loader").hide()
                },
                success:function(data){                                        
                    if (data.status) {
                        if (data.m.length > 0) {
                            $(".page-content-wrapper").html("");
                            $('html, body').animate({scrollTop:0}, 1000);
                            $(".tvd").val('');
                            $("input.mouseover").attr('value',1); 
                            for (var i = 0; i < data.m.length; i++) {                                                               
                                $(".page-content-wrapper").append(data.m[i].data);                                
                            }
                        }
                        $(".post_search").attr("data-curr",data.curr_sub);                        
                    }else{
                        if ($(".n-post").length > 0) {

                        } else{
                            $(".page-content-wrapper").html(data.no);
                        } 
                    }
                    more_func();
                },
                error:function(){
                    alert("Internet error, check your connection")
                }
            })
        }
    });
});
function refresh_page(l = false,curr = false){
    var pag = $(".page-holder").val()
    var to  = $("#"+pag).attr("value")
    if (l != false) {
        l = l;
    }
    else{
        l = 'not';
    }
    if (l != 'not') {
        $(".fetch-loader").show()
    }
    else{
        $(".main-loader").show()
    }
    if (to == 'feeds') {
        u = "getFeeds";
    }else{
        u = "getColFeeds";
    }                                                           
    $(".btn-spin").addClass("spin")
    $.ajax({
        url:u,
        type:"POST",
        data:{col:to,limit:l,curr:curr},
        complete:function(){
            $(".main-loader").hide()
            $(".btn-spin").removeClass("spin")
        },
        success:function(data){
            if (data.status) {
                if (data.m.length > 0) {                                       
                    $(".tvd").val('');
                    $("input.mouseover").attr('value',1); 
                    for (var i = 0; i < data.m.length; i++) {                                                               
                        $(".page-content-wrapper").append(data.m[i].data);
                    }
                }
                $(".post_search").attr("data-curr",data.curr_sub);
            }else{
                if ($(".n-post").length > 0) {

                } else{
                    $(".page-content-wrapper").append(data.no);
                }                    
            }           
        },
        error:function(){
            
        }
    })
}
function deletePost(id){
    var id_=id.value;
    var url_=$("#btn_didmiss").val();
    $.ajax({
            url:url_, 
            type:'POST',
            data:{identifier:id_}, 
            success: function (result) {
                $("#deletePost").modal("hide");
                refresh_page(15,0);
            }
        })
    };
function transferpost(id){
    var id_=id.value;    
    $("#repost_btn").val(id_);
}
function repostPost(id){
    var id_=id.value;
    var url_=$("#btn_didmiss_repost").val();    
    $.ajax({
        url:url_, 
        type:'POST',
        data:{i:id_}, 
        success: function (result) {
             if (result.status == true) {
                $(".repostPost").modal("hide");
                location.reload();
             }
             else{
                alert("An error occurred")
             }               
        }
    })
};
function transfer_edit(id){    
    $("#edit_textarea").val('');
    var id_=id;      
    if($(".p_table"+id_).attr("table") != null){
        var table = $(".p_table"+id_).attr("table")
    }
    else{
        var table ='posts';
    }   
    $("#save_btn").val(id_); 
    //loader.removeClass("hidden")      
    $.ajax({
        url:$(".main-url").val()+"getPostData",
        type:"POST",
        headers:{'user':'Talk'},
        data:{comm:id_,table:table},
        complete:function(){
             //loader.addClass("hidden")
         },
        success:function(data){               
            if (data.status == true) {
                var content = data.body; 
                CKEDITOR.instances['edit_textarea'].setData(content)                                        
            }
            else{
               alert("An error occurred");
            }
        },
        error:function(){               
            alert("An error occurred");
        }
    })  
 }

 function saveEdit(id){
    var id_= id.value;
    var url_= $("#btn_didmiss_save").val();
    var content=CKEDITOR.instances['edit_textarea'].getData(content); 
    $("#loader_edit").removeClass('hidden');
    $.ajax({
        url:url_, 
        type:'POST',
        data:{identifier:id_,content:content},
        complete:function(){
            $("#loader_edit").addClass('hidden');
        },
        success: function (result) {
            if (result.status) {
                $("#editPost").modal('hide');
                refresh_page(15,0)                    
            }else{
                alert(result.m)
            }
        },
        error:function(){
            alert("Internet error, check your connection")
        }
    })
};

function like(identifier) {
  var identifier = identifier.value;
  var auth = "";
  if (identifier != '') {
    $.ajax({
      url: base_url+'likePost',
      type: 'POST',
      data: {
        auth: auth,
        identifier: identifier
      },
      success: function(result) {
        if (result.status == 'like_exist') {
          $.ajax({
            url: $(".m_u_r").val() + 'posts/dl',
            type: 'POST',
            data: {
              auth: auth,
              identifier: identifier
            },
            success: function(result) {
              $("#likes_btn" + identifier).attr('style', 'color:#d9d9d9; ');
              $("#likes" + identifier).html(result.count);
            }
          })
        };
        if (result.status == 'liked') {
          $("#likes_btn" + identifier).attr('style', 'color:#cd0000; ');
        };
        $("#likes" + identifier).html(result.count);
      }
    })
  };
}

$(document).ready(function () {   
    loadNet();
    loaded();
    $(".main-cont").click(function(){        
        var div = $(this);
        div.scrollTop = div.scrollHeight;
        
    })
});

loaded = function(){
    $(".get-popular").click(function(){
        $(".main-loader").show();
        $.ajax({
            url:base_url+"getPopular",
            type:"POST",
            complete:function(){
                $(".main-loader").hide();
            },
            success:function(response){
                if (response.m.length > 5) {
                    $(".pop-body").html(response.m)
                    $(".tvd").val('');
                    $("input.mouseover").attr('value',1); 
                }else{
                    $(".pop-body").html("No posts yet")
                }
            },
            error:function(){
                alert("Internet error, try again")
            }
        })
    })
    $(".get-trends").click(function(){
        $(".main-loader").show();
        $.ajax({
            url:base_url+"getTrends",
            type:"POST",
            complete:function(){
                $(".main-loader").hide();
            },
            success:function(response){
                if (response.m.length > 5) {
                    $(".trend-body").html(response.m)
                    $(".tvd").val('');
                    $("input.mouseover").attr('value',1); 
                }else{
                    $(".trend-body").html("No posts trending now")
                }
            },
            error:function(){
                alert("Internet error, try again")
            }
        })
    })
}
function transfer(id){    
    var id_=id.value;
    $("#delete_btn").val(id_);
 }
function follow(user)
 {
    var id = user.value
    var i = id.substr(0, 5);
    $("#followed"+i).removeClass("glyphicon-plus")
    $("#followed"+i).html("<span class='glyphicon glyphicon-refresh spin'></span>")   
    $.ajax({
        url:"user/a_c",
        type:"POST",
        data:{id:id},
        success:function(data){
            if (data.status='success') {
                $("#followed"+i).html("")
                $("#followed"+i).removeClass("glyphicon-plus")
                $("#followed"+i).addClass("glyphicon-ok")
                $("#followed"+i).attr("onclick","");
                $("#followed"+i).attr("title","Followed")
                var count = $(".followed_count"+i).attr('value');
                count = parseInt(count)
                if ((count + 1) > 1) {
                    $(".followed_count"+i).html((count + 1) +"&nbsp;followers" )
                }
                else{
                    $(".followed_count"+i).html((count + 1) +"&nbsp;follower" )
                }
                refresh_page()
            }
            else{
                alert("An error occurred")
                $("#followed"+id).html("")
                $("#followed"+id).addClass("glyphicon-plus")
            }
        },
        error:function(){
            alert("An error occurred")
            $("#followed"+id).html("")
            $("#followed"+id).addClass("glyphicon-plus")
        }
    })
 }
function updateScroll(){
    var element = document.getElementById("msg_cont");
    element.scrollTop = element.scrollHeight;
}
function close_chat(){    
    $("#chat_").fadeOut("slow"); 
    $("#cont_chat").html('');
    $("#close_chat").attr('value','');
    $("#loader_chat").removeClass('hidden');
    clearInterval(rmess);
};
$(document).ready(function () {
        $(".copy_link").click(function(){
            var l = $(".p-link");
            l.select();
            document.execCommand("copy");
        })
        $("#search_box_pos").on('keyup',function () {
            $("#search_box_pos").val($(this).val());
        });
    });
$(document).ready(function () {
        base_url = $(".main-url").val()
        load_pop();
        load_trend();
        $("input#search_box_pos").on('keypress',function (e) {
             if(e.which == 13) {
                send()                               
             }           
        });
});
load_pop = function(){
    $.ajax({
        url:base_url+"getPopular",
        type:"POST",
        success:function(response){
            $(".pop-div").html(response.m);
        }
    })
}
load_trend = function(){
    $.ajax({
        url:base_url+"getTrends",
        type:"POST",
        success:function(response){
            $(".trend-div").html(response.m);
        }
    })
}
function loadNet() {       
}
function _cm()
{
var auth="";
var i = $(".m-ns").attr('value');
$.ajax({
    url:'messages/n_m', 
    type:'POST',
    data:{auth:auth}, 
    success: function (result) {
      if (result.status == true) {
        if (result.count != 0) {
            $("title").html("("+result.count+")&nbsp;"+"Talkpoint")
        }
        else{
            $("title").html("Talkpoint")
        }
        $(".b-cont").html(result.main);
        $("div#m_count").html(result.count);
        $("div.m_count").html(result.count);
        $(".circles_wrapper").html(result.net)
      }
    }
})      
} 
_cm(); 
setInterval(_cm, (10* 1000));

function togglem(){
    $(".btn-mpop").click();
}
function toggle_(btn){
    btn = btn.value;
    $("."+btn).click();
}
function close_(button)
{
    button=button.value;
    $("#"+button).click();
}
function see(id)
{
    var auth='';    
    $.ajax({
            url:'posts/see', 
            type:'POST',
            data:{n_id:id,auth:auth}, 
            success: function (result) {
                _count();
                $("#seen"+id).addClass('hidden');
                $(".notification"+id).attr('style','background: #f2f2f2;padding: 5px;cursor: pointer;color: black;margin-bottom: 1px;');
            }
     })
}
function _count()
{
    var auth='';    
    $.ajax({
            url:'posts/cn', 
            type:'POST',
            data:{auth:auth}, 
            success: function (result) {
                $("#_notify").html(result);                
            }
     })
}

function getComments(id) {
        var div= "post";
        var p_id=id.value;                
        var main_div=div+p_id;
        var url=$("#get_").val();        
        $.ajax({                
                url:url,
                type:'POST',
                data:{post:p_id},
                success:function (data) {
                 $("#"+main_div).html(data);                 
                }
        });
 } 
 function submitComment(id)
 {
    var pag = $(".page-holder").val()
    var to  = $("#"+pag).attr("value")
    var id_=id.value;
    var identifier=$("#post_id_comment"+id_).val();   
    var url=$("#url_submit_comment").val();
    var content=$("#comment_textarea"+id_).val();
    if (content!='') {
        $("#loader_image_comm").removeClass( "hidden" );
    $.ajax({
        url:url,
        type:'POST',
        data:{comment_data : content , identifier : identifier,page:to},
        success:function (data) {
           getComments(identifier);
           $("#comment_textarea"+id_).val("");
           $("#loader_image_comm").addClass( "hidden" );           
           f_com(identifier);
           refresh_page()                   
        }
    });
   };
 }
 function l_y(id)
  {
      var loader = $(".comm-loader")
      var c_id=id.value;
      var auth="";        
      if (!$("#r_cd"+c_id).hasClass("in")) {
          loader.removeClass('hidden');
          $.ajax({
              url:'posts/r_com', 
              type:'POST',        
              data:{auth:auth,c_id:c_id}, 
              success: function (result) {
                loader.addClass('hidden');
                if (result.status != false) {
                    $("#r_cd"+c_id).html(result.m);                  
                  }
              },
              error:function(){
                  loader.addClass('hidden');
              }
           })  
      }  
  }
function submitReply(id)
{
  var comment_id=id.value;    
  var reply= $("#reply_textarea"+comment_id).val();
  var auth ="";
  $.ajax({
      url:base_url+'r_comm', 
      type:'POST',
      data:{auth:auth,comment_id:comment_id,reply:reply}, 
      success: function (result) {
        if (result.status) {
          $("#reply_textarea"+comment_id).val("");
          $("#r_cd"+comment_id).html(result.data);
          $("#reply_counter"+comment_id).html(result.count); 
        }else{
          alert(resizable.m);
        }
      }
   })    
}
function c_reply(id){
    var comment_id=id.value;    
    alert(comment_id);
    var auth="";
    $.ajax({
        url:'posts/c_c', 
        type:'POST',
        data:{auth:auth,comment_id:comment_id}, 
        success: function (result) {
          $("#reply_counter"+comment_id).html(result);
        }
     })  
}

function rss(){ 
var pag = $(".page-holder").val()
var to  = $("#"+pag).attr("value")   
var source="std";        
$.ajax({
        url:'posts/gr', 
        type:'POST',
        data:{source:source,page:to}, 
        success: function (result) {
            var source="nyt";
            $.ajax({
                    url:'posts/gr', 
                    type:'POST',
                    data:{source:source,page:to}, 
                    success: function (result) {                           
                    }
                })
        }
    })
};
$(window).scroll(function(){
    if ($(window).scrollTop() + $(window).height() == $(document).height() - 0 ) {
        var count = $("._lta").val()
        var curr = $(".post_search").attr("data-curr")
        //refresh_page(5,curr);     
     }
})
function cl_n(){
    $.ajax({
        url:"user/cl_n",
        type:"post",
        success:function(data){
            if (data.status == true) {
                location.reload();
            }
        }
    })
}
$(document).on('mousemove',function () { 
 var count = $("input.mouseover").val()
    if(count < 10 ){
        $("input.mouseover").attr('value',+2 + +count)
    }
    if (count < 3) {         
    //other  
    $(".cl_n").click(function(){
        
    })     
    $(".p_sin").each(function(){
        $(this).click(function(){
            id = $(this).attr('value');
            f_com(id,'posts')
        })
    })
    $(".link-share").each(function(){
        $(this).click(function(){
            var link = $(this).attr("data-src")
            $(".p-link").val(link);
        })
    })     
    $(".glyphicon-heart").each(function(){ 
        var v = $(this).attr('value')              
        $(this).mouseup(function(){
            clearTimeout(pressTimer)
            return false;
        })
        $(this).mousedown(function(){
            pressTimer = window.setTimeout(function(){
                var user = $(".b-user")
                var head = $(".b-head")
                var comment = $(".b-com")
                var loader = $(".comm-loader")
                var content = $(".b-pcont")
                var detail = $(".p-det")
                //
                loader.removeClass("hidden")
                $(".barr").removeClass("hidden")
                $.ajax({
                    url:$(".main-url").val()+"posts/gl_p",
                    type:"POST",
                    headers:{'user':'Talk'},
                    data:{post:v},
                    success:function(data){
                        loader.addClass("hidden")
                        if (data.status == true) {
                            user.html(data.user);
                            head.html(data.head);
                            comment.html(data.comment)
                            content.html(data.content)
                            detail.html(data.detail);
                        }
                        else{
                            head.html("Post could not be found")
                        }
                    },
                    error:function(){
                        loader.addClass("hidden")
                        head.html("Post could not be found")
                        user.html("")               
                        comment.html("")
                        setTimeout(function(){
                            var v =""
                            f_com(v)
                        },2000)
                    }
                })
            }, 500)
            return false;
        })
    })
    $(".progress").each(function() {
        $(this).on("click",function(e){
          var id = $(this).attr("id");
          var w = e.offsetX / $(this).width() * 100;
          var v = document.getElementById("vid"+id);
           var duration = v.duration;                        
           if (w > 100)
            w = 100;
           var cur = (duration * w)/100
           $(this).children(".progress-bar").attr("style","width:"+w+"%;");
           $(this).children(".m_m").title = Math.round(w); 
           v.currentTime = cur;       
        });        
    });
    $(".media-progress").each(function() {        
	      var id = $(this).attr("id");	      
	      var v = document.getElementById("vid"+id);
	      $(".drag").attr("style","width:"+ v.volume * 100 +"%;");	      
    });
    $(".v_pl").each(function() {   
    	  var id = $(this).attr("value");  
    	  var v = document.getElementById("vid"+id);   
	      $(this).on("mouseover",function(){           
	      	//$(".vpl-p"+id).fadeIn("slow")
	      })
	      $(this).on("mouseleave",function(){
	      	var btn = $(".play-pause"+id);
	      	if(btn.hasClass('paused')){
	      		//$(".vpl-p"+id).fadeOut("slow")
	      	}
	      })
	      $(".rpt"+id).on("click",function(){
	      	if ($(this).attr("value") == 'off') {
	      		v.loop = false;	      		
	      		$(this).attr("value","on")     		
	      	}
	      	else{	      	    	
	      		v.loop = true;  	      		
	      		$(this).attr("value","off")     		
	      	}
	      })
	      w = $(".vid"+id).attr("volume")*100;
	      $(".drag"+id).attr("style","width:"+w+"%;");            
          v.volume = w/100; 	  	      
    });    
    $(".player").each(function() {
	  $(this).mousedown(function(e){ 
	  	var id = $(this).attr("value");	  		  	 
	    if( e.button == 2 ) { 
	      $(".sto"+id).click()	      
	      return false; 
	    } 
	    return true; 
	 });
	});
    $("video").each(function() {        
	     $(this).on("mousedown",function(e){
	     	if (e.button == 2) {
                
            }
	     })                
    });
    $(".v-control").each(function() {
        $(this).on("click",function(e){
          var id = $(this).attr("value");
          var w = e.offsetX / $(this).width() * 100;
          var v = document.getElementById("vid"+id);                       
           if (w > 100)
            w = 100;          
            $(".drag"+id).attr("style","width:"+w+"%;");            
            v.volume = w/100;                       
        });        
    });
    $(".player").each(function() {
    	var id = $(this).attr("value");
        $(".vid"+id).on("click",function(e){          
              //tp(id)                 
        });        
    });

	    //main
    var lesstext = "less";
    var moretext =  "... See More";
   /* $(".main-content").each(function(){        
        var div = $(this);        
        var show = 300;  
        var id ="span"+div.attr("id")      
        html = div.html()
        var new_h = html.substr(0, show);
        var remaining = html.substr(show, html.length) 
        var text = new_h + '<span id="'+ id +'" class="hidden">'+remaining+'</span>&nbsp;<a style="text-decoration:none;" value="'+id+'" class="morelink">'+moretext+'</a>';           
        if (html.length > show) {
            div.html(text)
        }; 
     })*/
     $(".morelink").each(function(){
        $(this).click(function(){
            var lesstext = "less";
            var moretext =  "...See More";
            var id = $(this).attr("value")
            if($(this).hasClass("less")) {
                $(this).removeClass("less");
                $(this).html(lesstext);
                $("#span"+id).removeClass("hidden");                                                           
            } else {
                $(this).addClass("less");
                $(this).html(moretext);
                $("#span"+id).addClass("hidden");                                                             
            }                                  
        })            
    });    
    $("img").each(function(){
        $(this).click(function(){
            if ($(this).parent().hasClass("img-article")) {
                var src = $(this).attr("src")
                $("#picmodal").modal("show");            
                $(".pic-disp").attr("src",src)  
            }                                            
        })
    })
};      
});
function adds() {
    var auth ="";
    $.ajax({
        url: "adds/load", 
        type:"POST",
        data:{auth:auth},
        success: (function (result) {
            $(".add-wrapper").html(result);

        })
    })
};
adds();     
setInterval(adds, (30* 1000));

function vp(post){	
    var v = document.getElementById("vid"+post);
    inner = $(".buffer"+post);
    main = $(".vid-progress"+post);             
    var b= Math.floor((v.buffered / v .duration) * 100
    );  
    v.addEventListener("timeupdate", function() {	   
	   if(!isNaN(this.duration)) {
	        var width = Math.floor((v.currentTime / v .duration) * 100);
	        main.attr("style","width:"+width+"%");
	        var r = v.currentTime;	               
	        var t = v .duration;	         
	        $(".v_c_t_r"+post).html(timeFormat(r) + "/" + timeFormat(t));		             	       
	    }
	    var btn = $(".play-pause"+post);
	  	if (v.ended) {
	  	  btn.attr("title",'play');
	      btn.addClass("glyphicon-play");
	      btn.addClass("stopped");      
	      btn.removeClass("glyphicon-pause");
	      btn.removeClass("playing");
	      btn.removeClass("paused"); 
	  	}; 	
	});
	v.addEventListener("progress", function() {
		if(!isNaN(this.duration)) {
			var range = 0;
		    var bf = this.buffered;
		    var time = this.currentTime;

		    while(!(bf.start(range) <= time && time <= bf.end(range))) {
		        range += 1;
		    }
		    var bs = bf.start(range) / this.duration;
		    var be = bf.end(range) / this.duration;
		    var b = be - bs;
	        inner.attr("style","width:"+b * 100+"%");
		}		
	});
}
function tp(id) {
   if (id.length > 30 ) {
   	var post = id
   }
   else{
   	var post = id.value
   }
   var btn = $(".play-pause"+post);
   vid = $('.vid'+post);
   var v = document.getElementById("vid"+post);
   var tvd = $(".tvd").val();
   var vs = document.getElementById("vid"+tvd);
   v.addEventListener('timeupdate', vp(post), true);
   if (btn.hasClass("playing") || btn.hasClass("stopped")) {
      btn.attr("title",'play');
      btn.removeClass("glyphicon-play");
      btn.removeClass("stopped");      
      btn.addClass("glyphicon-pause");
      btn.removeClass("playing");
      btn.addClass("paused"); 
      if (tvd !="" && tvd != post && vs !=null) {      	  
      	  var btn = $(".play-pause"+tvd);
      	  $('.vid'+tvd).get(0).pause()
	      	btn.addClass("playing");
	      btn.removeClass("paused");
	      btn.attr("title",'play');
	      btn.addClass("glyphicon-play");
	      btn.removeClass("glyphicon-pause");	      
      };
      vid.get(0).play()         
      $(".tvd").val(post)                                    
   }
   else {
      btn.addClass("playing");
      btn.removeClass("paused");
      btn.attr("title",'pause');
      btn.addClass("glyphicon-play");
      btn.removeClass("glyphicon-pause");      
      vid.get(0).pause()   
      vp(post)
   }
}
function menus(setting){
	setting = setting.value
	var set = $(".setting"+setting);
	if (set.hasClass('faded')) {
		set.fadeIn("slow")
		set.removeClass('faded')
	}else{
		set.fadeOut("slow")
		set.addClass('faded')
	}
}
function t_c(vid){
	var post = vid.value
    var vid = document.getElementById("vid"+post);
	if (vid.requestFullscreen) {
	  vid.requestFullscreen();
	} else if (vid.mozRequestFullScreen) {
	  vid.mozRequestFullScreen();
	} else if (vid.webkitRequestFullscreen) {
	  vid.webkitRequestFullscreen();
	}
}
function tc(control){
	var control = $(".player-controls"+control);
	control.removeClass("hidden")
	alert(control)
}
function rc(control){
	var control = $(".player-controls"+control);	
	control.addClass("hidden");
}
function m(mt){
	var post = mt.value
	var v = document.getElementById("vid"+post);
	vid = $('.vid'+post);
	var btn = $(".mute"+post);
	if (btn.hasClass("high")) {
		btn.addClass("low")
		btn.attr("title","unmute");
		btn.removeClass("high")
		btn.removeClass("glyphicon-volume-up")
		btn.addClass("glyphicon-volume-off")
		vid.prop('muted',true);
	}
	else{
		btn.removeClass("low")
		btn.addClass("high")
		btn.attr("title","mute");
		btn.removeClass("glyphicon-volume-off")
		btn.addClass("glyphicon-volume-up")
		vid.prop('muted',false)
	}
}
function closeRequests()
{
    $("#c_t").click();
}
function tag(tile){
  $("#tag_result").html(tile +"<br>"+tile)
}
$(document).ready(function(){
    $(".talk-btn").click(function(){
        var message = $("#talk-box").val()
        if (message.trim()) {
            $.ajax({
                url:'user/talk',
                type:'POST',
                data:{message:message},
                success:function(result){
                    if (result =='sent') {
                        $("#talk-box").val('')                        
                        $(".sent-alert").addTemporaryClass("unhidden", 5000);
                    };
                },
                error:function(){                                                       
                }
            })
        };
    })
    $("input#talk-box").on('keypress',function (e) {
             if(e.which == 13) {
                $(".talk-btn").click()                             
             }           
    });    
})
function _ust(){
    var x = new (window.ActiveXObject || XMLHttpRequest)("Microsoft.XMLHTTP");
    var s;

    x.open("HEAD", "//" + window.location.hostname+ "/?" /*+ Math.floor((1 +Math.random())* 0x10000)*/,false);

    try{
        x.send()
        return x.status;
    }catch(error){
        return x.status;
    }
}