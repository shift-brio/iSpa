(function($){
"use strict";
 var res = {};
 $.fn.validate = function(f,o = false,a = false,u =  false, type = false){
 	var f = $("."+f);
 	if (o != false) {
 		if (o == 'd') {
 			var v = f.html();
 		}
 		else if(o == 'empt'){
 			var em = true;
 		
 		 	}
 	else{
 		var v = f.val();
 	}
 	if (a != false) {
 		var vt = v.replace(/\s/g, '').length;
 	}
 	else{
 		var vt = v.length;
 	}
 	if (vt > 0) {
 		if (u != false) { 		
	 		var p = /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/;
		    if(!p.test(v)) {		              
		       res.response = false;
		       res.message  = "Invalid Url";	                       		   		 
			} else {	
			   res.response = true;			           	 		   
			}			
	 	}
	 	else{
	 		if (type != false) {
	 			if (type.main == "normal") {
	 				if (vt < type.length || vt == type.length) {
	 					res.response = true;	 				    
	 				}
	 				else{
	 					res.response = false;
	 				    res.message = "Long text";
	 				}
	 			}
	 			else{	 				
	 			}
	 		}
	 		else{
	 			res.response = null;
	 		}	 		
	 	} 	
	 	console.log(res.response+" "+ res.message)	   	 
		return res; 
 	}
 	else{
 		res.response = false;
 		console.log(res.response +" "+ res.message)	   	 
		return res; 
 	}
 } 
}(jQuery));
$(document).ready(function(){
	_t();
})
var _t = function(){
	var valid = false;
	var valid_c = [];
	valid_c[0] = "test";
	var max_valid = 11;
	$("input,textarea").each(function(){
		$(this).on("blur",function(){
			var input = $(this);
			var t = $(this).attr("type");
			var p = $(this).attr("placeholder");
			var te =$(this).val();
			if (t != null && $(this).val() == '' && !$(this).hasClass("op-con")) {
				if (!$(this).hasClass("b-des")) {
					$(this).addClass("emt");
				}
				var removeItem = $(this).attr("name");
				if ($.inArray($(this).attr("name"),valid_c) != -1) {
					valid_c = jQuery.grep(valid_c, function(value){						
						return value != removeItem;						
					})					
				}
				alert(valid_c.length);
				$(this).attr("placeholder","Enter valid value here");
				setTimeout(function(){
				 input.attr("placeholder",p);
				},5000)				
			}
			else{
				$(this).removeClass("emt");
				if (t == "text") {
					if ($(this).hasClass("s_l")) {
						var res = input.validate("s_l",false,true,true, false);
						if (res.response == false) {
							$(this).attr("placeholder","Enter a valid url");
						}
					}
					else{
					   var type = [];
					   if (input.hasClass("b-des")) {
					   	type.length = 300;
					   	var av = false;
					   	type.main = "long";
					   } 
					   else{
					   	type.main = "normal";
					   	var av = true;
					   	type.length = 80;
					   }
					   var res = input.validate(input.attr("name"),false,av,false, type);
					}
				}
				else if(t == "email"){

				}
				else if(t == "password"){

				}
				if((valid_c.length < max_valid  || valid_c.length == max_valid) && $.inArray($(this).attr("name"),valid_c) == -1){					
					valid_c.push($(this).attr("name"));
					alert(valid_c.length)					
				}				

			}
		})
	})
}
v => return 2 + 1;